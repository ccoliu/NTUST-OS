#include "syscall.h"
main()
	{
		int	n;
		for (n=9;n>0;n--);
			//PrintInt(n);
	}
