#include "syscall.h"

main()
        {
                int     n;
                for (n=10000;n<=10010;n++)
                        PrintInt(n);
        }
